# 🖼️ React Image Gallery

This project is a minimalist, modular, and fully functional image gallery built with React.

## 🚀 Setup Instructions

1. Clone the repo or copy the `src/components` folder into your project.
2. Ensure you have React setup (e.g., using Create React App or Vite).
3. Place your images data as an array of objects like:
   ```js
   const images = [
     { src: "/img1.jpg", alt: "Image 1", title: "Beautiful Sunset" },
     ...
   ];
   ```
4. Use it in your App:
   ```jsx
   import Gallery from './components/Gallery';

   function App() {
     return <Gallery images={images} />;
   }
   ```
5. Run the app:
   ```bash
   npm install
   npm start
   ```

## 🛠 Tech Stack

- React
- CSS Grid
- Functional Components

## 💡 Future Enhancements

- Modal preview / Lightbox
- Lazy loading for performance
- Dynamic image fetch from API
