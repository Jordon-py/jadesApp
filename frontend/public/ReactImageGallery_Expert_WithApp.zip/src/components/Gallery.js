import React from 'react';
import ImageTile from './ImageTile';
import './Gallery.css';

/**
 * Gallery Component
 * Renders a grid of images using the ImageTile component.
 * Props:
 * - images: Array of image objects [{ src, alt, title }]
 */
const Gallery = ({ images }) => {
  return (
    <div className="gallery">
      {images.map((img, index) => (
        <ImageTile key={index} {...img} />
      ))}
    </div>
  );
};

export default Gallery;
