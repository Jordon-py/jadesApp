import React from 'react';

/**
 * ImageTile Component
 * Displays a single image with title overlay.
 * Props:
 * - src: Image source URL
 * - alt: Alternative text
 * - title: Title overlay
 */
const ImageTile = ({ src, alt, title }) => (
  <div className="image-tile">
    <img src={src} alt={alt} />
    <div className="title-overlay">{title}</div>
  </div>
);

export default ImageTile;
