import React from 'react';
import Gallery from './components/Gallery';
import './App.css';

const images = [
  { src: "https://via.placeholder.com/300", alt: "Placeholder 1", title: "Sample Image 1" },
  { src: "https://via.placeholder.com/300", alt: "Placeholder 2", title: "Sample Image 2" },
  { src: "https://via.placeholder.com/300", alt: "Placeholder 3", title: "Sample Image 3" }
];

function App() {
  return (
    <div className="App">
      <h1>React Image Gallery</h1>
      <Gallery images={images} />
    </div>
  );
}

export default App;
